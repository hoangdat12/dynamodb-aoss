import boto3
import requests
from requests_aws4auth import AWS4Auth
import os

region = os.environ.get("REGION")
service = os.environ.get("AWS_SERVICE")
credentials = boto3.Session().get_credentials()
awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)

host = os.environ.get("OPENSEARCH_HOST")  
index = os.environ.get("OPENSEARCH_INDEX")
datatype = os.environ.get("OPENSEARCH_DATATYPE")
headers = {"Content-Type": "application/json"}

INSERT = "INSERT"
MODIFY = "MODIFY"
REMOVE = "REMOVE"

def lambda_handler(event, context):
    print(event)
    
    url = f"{host}/{index}/{datatype}"
    
    for record in event["Records"]:
        event_name = record["eventName"]
        
        if (event_name == INSERT or event_name == MODIFY):
            transformed_data = {}
            event_data = record["dynamodb"]["NewImage"]
            
            for key in event_data.keys():
                transformed_data[key] = event_data[key]["S"];
            
            if (event_name == INSERT):
                r = requests.post(url, auth=awsauth, json=transformed_data, headers=headers)
            else:
                r = requests.put(url, auth=awsauth, json=transformed_data, headers=headers)
            
            if r.status_code != 201 and r.status_code != 200:
                print(f"Failed to index item: {transformed_data}, Response: {r.text}")
            else:
                print(f"Successfully: {transformed_data}")
                
        elif (event_name == REMOVE):
            unique_id = record["dynamodb"]['Keys']['id']['S']
            
            delete_url = url + unique_id;
            
            r = requests.delete(delete_url, auth=awsauth, headers=headers)
    
            if r.status_code != 200:
                print(f"Failed to remove item with ID {unique_id}, Response: {r.text}")
            else:
                print(f"Removed item successfully with ID {unique_id}")
        
        
