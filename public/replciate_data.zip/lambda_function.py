import boto3
import gzip
import json
import requests
from requests_aws4auth import AWS4Auth
import io  # Import the io module
import os

# Initialize AWS clients
s3 = boto3.client('s3')
region = os.environ.get('REGION')  # Update with your region
service = os.environ.get('AWS_SERVICE')
credentials = boto3.Session().get_credentials()

print(credentials.access_key, credentials)

awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)

# OpenSearch configuration
host = os.environ.get('OPENSEARCH_HOST')
index = os.environ.get('OPENSEARCH_INDEX')
datatype = os.environ.get('OPENSEARCH_DATATYPE')
headers = {"Content-Type": "application/json"}

print(region, service, host, index, datatype)

def lambda_handler(event, context):
    url = host + '/' + index + '/' + datatype

    # Get the bucket name and key for the uploaded file
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    
    # Download the gzipped file from S3
    gz_obj = s3.get_object(Bucket=bucket, Key=key)
    gz_content = gz_obj['Body'].read()
    
    # Decompress the gzipped file
    with gzip.GzipFile(fileobj=io.BytesIO(gz_content), mode='rb') as gz:
        backup_content = gz.read().decode('utf-8')
    
    dict_str_list = backup_content.strip().split('\n')
    
    # Parse DynamoDB backup content and index to OpenSearch
    for match in dict_str_list:
        item = json.loads(match)['Item']
        transformed_data = {}
        for key in item.keys():
            transformed_data[key] = item[key]["S"];
        
        # Index the item to OpenSearch
        r = requests.post(url, auth=awsauth, json=transformed_data, headers=headers)
        if r.status_code != 201:
            print(f"Failed to index item: {item}, Response: {r.text}")
        else:
            print(f"Indexed item successfully: {item}")